function ajouterObjectif(){
    var nouvel_objectif=document.getElementById('nouveau_objectif').value;
    if(nouvel_objectif!==''){
        var listeObjectifs=document.getElementById('element');
        var nouvelElement=document.createElement('li');
        nouvelElement.textContent=nouvel_objectif;
        listeObjectifs.appendChild(nouvelElement);
        nouvel_objectif=document.getElementById('nouveau_objectif').value='';
    }
}
